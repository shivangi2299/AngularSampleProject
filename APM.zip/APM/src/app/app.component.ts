import { Component } from '@angular/core';
import { Router } from '@angular/router'; 

@Component({
  selector: 'pm-root',
  template: `
    <div>
      <nav class ='navbar navbar -default'>
        <div class='container-fluid'>
         <a class='navbar-brand'>{{pageTitle}}</a><br>
         <ul class='nav navbar-nav'>

              <li><a [routerLink]="['EmployeeDetails']">Employee List</a></li>
              <li><a [routerLink]="['add-new-employee']">+Add new Employee</a></li>
          </ul>
        </div>
      </nav>
      <div class='container'>
          <router-outlet></router-outlet>
      </div>

    </div>
    `
    

    
})  
export class AppComponent {
  pageTitle:string='Employee Details';
  
  

  

    
    
  
}

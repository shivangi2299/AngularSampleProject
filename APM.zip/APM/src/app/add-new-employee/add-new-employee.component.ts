import { Component, OnInit } from '@angular/core';
import { EmployeeDetailsComponent } from '../EmployeeDetails/employee-details.component';
import { IDetails } from '../EmployeeDetails/employee-details.interface';
import { EmployeeService } from '../EmployeeDetails/employee.sevices';

@Component({
  selector: 'pm-add-new-employee',
  templateUrl: './add-new-employee.component.html',
  styleUrls: ['./add-new-employee.component.css']
})
export class AddNewEmployeeComponent implements OnInit {
 
  detail:IDetails=new IDetails();
  submitted = false;

  constructor(private _detailService: EmployeeService) { }
  ngOnInit() {
  }
  save() {
    this._detailService.createEmployee(this.detail)
      .subscribe(data => console.log(data), error => console.log(error));
    this.detail = new IDetails();
  }
  
  onSubmit()
  {
    this.submitted = true;
    this.save();
    
  }

}

import { NgModule } from '@angular/core';


import { AddNewEmployeeComponent } from '../app/add-new-employee/add-new-employee.component';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeDetailsComponent } from './EmployeeDetails/employee-details.component';

const routes: Routes=[
  { path: '', redirectTo: 'employee', pathMatch: 'full' },
  {path:'EmployeeDetails',component :EmployeeDetailsComponent},
  {path:'add-new-employee',component :AddNewEmployeeComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports:[RouterModule]
    
   
  
})
export class AppRoutingModule { }

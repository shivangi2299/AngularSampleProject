import { Component, OnInit } from "@angular/core";
import { RouterLink } from "@angular/router";

import { IDetails } from "./employee-details.interface";
import { EmployeeService } from "./employee.sevices";
import { Observable, Subscription } from 'rxjs';

@Component({
    
    templateUrl:'./employee-details.component.html'
})

export class EmployeeDetailsComponent implements OnInit{
   
    pageTitle:string='Employee Details';
    
    details: IDetails[]; 
    
    errorMessage:string;
    

       
    constructor (private _detailService:EmployeeService){
        
    }
    
    ngOnInit(): void 
    {
       
        
             this._detailService.getDetails()
            .subscribe(details => {
                return this.details = details;
            } ,  
                error => this.errorMessage = <any>error);
        

        
    }


}
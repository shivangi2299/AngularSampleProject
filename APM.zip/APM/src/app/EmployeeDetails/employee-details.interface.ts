export class IDetails{
        employeeName:string;
        employeeId:number;
        employeeAge:number;
        employeeDesignation:string;
    
}
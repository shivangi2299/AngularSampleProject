import { Injectable } from "@angular/core";
import {HttpClient, HttpErrorResponse} from '@angular/common/http';
import { IDetails } from "../EmployeeDetails/employee-details.interface";

import { Observable } from "rxjs/Observable";
import 'rxjs/add/observable/throw';
import 'rxjs/add/operator/catch';
import  'rxjs/add/operator/do';




@Injectable()


export class  EmployeeService{
    
    
    private _detailUrl='./api/details/details.json';
    
    constructor(private _http: HttpClient){}
    getDetails():Observable<IDetails[]> 
    {
        return this._http.get<IDetails[]>(this._detailUrl)
            .do(data => console.log('All: ' + JSON.stringify(data)))
            .catch(this.handleError);   
    }
    private handleError(err:HttpErrorResponse){
        console.log(err.message);
        return Observable.throw(err.message);
    }
    
    createEmployee(detail: IDetails): Observable<any> {
        return this._http.post(`${this.getDetails()}`, detail);
      }
   
    
    
    

}
